/*
    COSC 316 - Lab 1
    Name: Thi Anh Thu Nguye
    Student ID: 300290862
 */
import UIKit

// 1.a
func printPrimeNummbers (num1: Int, num2: Int) {
    for num in num1...num2 {
        if (num >= 2) {
            var i: Int = 2
            var count: Int = 0
            while (i < num) {
                if (num % i == 0) {
                    count += 1
                    break
                } else {
                    i += 1
                }
            }
            if (count == 0) {
                print (num)
            }
        }
    }
}
// 1.b
func getPrimeNumbers (num1: Int, num2: Int) -> [Int] {
    var primeNums = [Int]()
    for num in num1...num2 {
        if (num >= 2) {
            var i: Int  = 2
            var count: Int = 0
            while (i < num) {
                if (num % i == 0) {
                    count += 1
                    break
                } else {
                    i += 1
                }
            }
            if (count == 0) {
                primeNums.append(num)
            }
        }
    }
    return primeNums
}
// 1.c
let primeNumbers: (Int, Int) -> [Int] = { (num1, num2) -> [Int] in
    var primeNums = [Int]()
    for num in num1...num2 {
        if (num >= 2) {
            var i: Int  = 2
            var count: Int = 0
            while (i < num) {
                if (num % i == 0) {
                    count += 1
                    break
                } else {
                    i += 1
                }
            }
            if (count == 0) {
                primeNums += [num]
            }
        }
    }
    return primeNums
}
// call functions
printPrimeNummbers (num1: 1, num2: 50)
print (getPrimeNumbers(num1: 1, num2: 50))
print (primeNumbers(1, 50))

