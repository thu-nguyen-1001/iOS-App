//
//  SwiftUITutorialApp.swift
//  SwiftUITutorial
//
//  Created by Daniel Ling on 2022-03-10.
//

import SwiftUI

@main
struct SwiftUITutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(rGuess: 0.5, gGuess: 0.5, bGuess: 0.5)

        }
    }
}
