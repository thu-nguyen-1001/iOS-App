/*
    COSC 316 - Lab 1
    Name: Thi Anh Thu Nguye
    Student ID: 300290862
 */
import UIKit

// 2.a
func payCheck (_ name: String, _ hoursworked: Double, _ hourlyrate: Double, _ bonus: Double = 0.0) -> String {
    var pay :Double
    if (hoursworked > 80) {
        pay = 80 * hourlyrate + (hoursworked - 80) * hourlyrate * 1.5 + bonus
    } else {
        pay = hoursworked * hourlyrate + bonus
    }
    return String(format: "%@: $%.2f", name, pay)
}
// call functions
print (payCheck("John Doe", 70.5, 21.5, 150.0))
print (payCheck ("Peter Chan", 88.5, 20.0))

// 2.b
func reverseDigits(_ num: Int, _ reversedStr: String) -> String {
    if (num == 0 && reversedStr == "") {
            return "0";
    }
    if (num == 0 && reversedStr != "") {
        return reversedStr;
    }
    if (num < 0) {
        return reverseDigits(-num, "-")
    }
    // if num > 0
    return reverseDigits(num / 10, reversedStr + String(num % 10))
}
// call functions
print (reverseDigits (1234, ""))
print (reverseDigits (-1230, ""))
print (reverseDigits (0, ""))

