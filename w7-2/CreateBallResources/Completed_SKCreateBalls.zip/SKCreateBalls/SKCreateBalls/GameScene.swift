//
//  GameScene.swift
//  SKCreateBalls
//
//  Created by Daniel Ling on 2020-02-15.
//  Copyright © 2020 Daniel Ling. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    override func didMove(to view: SKView) {
            backgroundColor = UIColor.white

            scene!.physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
            run(SKAction.repeat(SKAction.sequence([SKAction.run(createBall), SKAction.wait(forDuration: 0.05)]), count: 200))

    }
    
    func createBall() {
        let ball = SKSpriteNode(imageNamed: "ball")
        ball.position = CGPoint(x: CGFloat(Int(arc4random()) & Int(size.width)), y: size.height - ball.size.height)
        // try these fractions for different effects : 1, 2/3, 1/2, 1/3
        ball.physicsBody = SKPhysicsBody(circleOfRadius: ball.size.width*1/2)
        addChild(ball)
    }
}
